---
title: self.class == super.class
date: 2016-10-18 20:13:52
categories:
- iOS简笔记
tags:
- class
- runtime
- objc
---
假设有一个类Person：NSObject，在类的实例方法中调用：

NSLog(@"%@", [self class]);

NSLog(@"%@", [super class]);

会发现这两行的输出结果都是Person。
<!-- more -->

## Self是什么？
self是OC提供的保留字，代表当前方法的调用者，在实例方法中指向对象，在静态方法中指向类，self是方法的隐藏的参数变量，另外一个隐藏参数变量是SEL _cmd，代表当前方法的@selector。

## Super是什么？
super是OC提供的保留字，但不是隐藏参数，它只是一个编译器指示符。发送调用方法的消息时，指定方法查找的位置在父类。

我们知道调用self.class时，其实是runtime库调用objc_msgSend(self, @selector(getClass))
那么调用super.class，在运行时则变为objc_msgSendSuper(struct objc_super *super, SEL op, ...)
这个objc_super的构造如下：

	struct objc_super {
	
	__unsafe_unretained id receiver;
	#if !defined(__cplusplus)  &&  !__OBJC2__
	__unsafe_unretained Class class;
	
	#else
	__unsafe_unretained Class super_class;
	#endif
	
	};
	

其中receiver指向了类Person的实例，而super\_class指向Person的父类，当执行objc\_msgSendSuper时，会从super_class的方法列表中开始查找，也就是跳过了Person类的查找。那么找到方法后回向receiver发送消息，关键就在于这里，向receiver发送消息等同于objc\_msgSend\(receiver, @selector\(getClass\)\)，也就是说，super.class和self.class的消息接受者是一样的，也就是Person的实例，所以最终获得的Class都是Person类。