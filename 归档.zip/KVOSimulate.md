---
title: KVOSimulate
date: 2016-11-04 16:36:26
categories:
- iOS简笔记
tags:
- kvo
- runtime
- objc
---

KVO，即Key-Value Observing，是OC的一种机制，允许对象监听其他对象的属性，当属性值发生改变时获得函数回调。KVO的特点是不需要修改被监听的对象即可实现通知功能，这一功能的实现就是利用了OC强大的Runtime特性。因此我们通过Runtime来模拟一个KVO的实现，从而进一步理解KVO。

## KVO原理简述
首先简述下KVO的实现原理，当调用给对象添加监听者的方法时，OC会动态的创建一个该对象的子类，在子类中重写被监控属性的setter方法，在重写的setter方法中，子类会调用父类的setter方法，并且在setter方法执行的前后调用监听者的回调函数。同时，子类还会重写getClass方法，使其返回父类的Class，从而完成类的伪装。创建完子类之后，OC会将被监听对象isa指针指向新创建的子类，这样当子类调用相应属性的setter方法时，就会执行新的方法。
<!-- more -->


## KVO的缺陷
KVO的功能并不全面，使用起来也有很多局限性。例如，KVO不支持自定义的selector，也不支持block，所有的通知都要在指定的回调函数中接收。另外，监听者的父类也有可能监听了一些对象属性，如果没有在子类中调用父类的方法，就会是父类的监听失效，而且，监听者是父类还是子类主要靠context来区分，一旦在子类监听中定义的context与父类重名，一方面父类的监听会失效，另一方面同一个keypath进行两次removeObserver操作会导致程序crash。

## KVO具体实现过程
接下来我们通过代码来演示KVO的实现过程

1.首先我们新建了一个NSObject类的Category，添加三个方法，分别是添加监听者、移除监听者以及属性值改变时的回调方法。
@interface NSObject (LKVO)

- (void)l_addObserver:(NSObject *)observer withKeyPath:(NSString *)keyPath;

- (void) l_observingWithKeyPath:(NSString *)keyPath object:(NSObject *)observed change:(NSDictionary *)change;

- (void)l_removeObserver:(NSObject *)observer keyPath:(NSString *)keyPath;

@end

2.接下来实现l_addObserver:withKeyPath:方法
		
	- (void)l_addObserver:(NSObject *)observer withKeyPath:(NSString *)keyPath {

    // 1.create KVO class
    Class obj_class = object_getClass(self);
    char const *class_name = class_getName(obj_class);

    char kvo_class_name[strlen(class_name)+strlen(LKVO_suffix)+1];
    strcpy(kvo_class_name, class_name);
    strcat(kvo_class_name, LKVO_suffix);

    Class kvo_class = objc_getClass(kvo_class_name);
    if (!kvo_class) {
        kvo_class = objc_allocateClassPair(obj_class, kvo_class_name, 0);
        objc_registerClassPair(kvo_class);

        // 2.override getClass method
        class_replaceMethod(kvo_class, NSSelectorFromString(@"class"), (IMP)fakeClassMethod, "@@:");

    }

    // 3.replace setter method
    NSString *methodName = [NSString stringWithFormat:@"%@%@", [[keyPath substringWithRange:NSMakeRange(0, 1)] uppercaseString], [keyPath substringWithRange:NSMakeRange(1, keyPath.length-1)]];
    NSString *selName = [NSString stringWithFormat:@"set%@:", methodName];
    SEL selector = NSSelectorFromString(selName);
    class_replaceMethod(kvo_class, selector, (IMP)methodSetter, "v@:@");

    // 4.change isa to KVO class
    object_setClass(self, kvo_class);


    // 5.associate observer with observed
    NSString *keyName = [NSString stringWithFormat:@"%@%@", [[keyPath substringWithRange:NSMakeRange(0, 1)] lowercaseString], [keyPath substringWithRange:NSMakeRange(1, keyPath.length-1)]];
    id dict = objc_getAssociatedObject(self, key_associated);
    NSMutableDictionary *mDict = nil;
    if (dict && [dict isKindOfClass:[NSDictionary class]]) {
        mDict = [[NSMutableDictionary alloc] initWithDictionary:dict];
    } else {
        mDict = [[NSMutableDictionary alloc] init];
    }
    NSMutableArray *array = [mDict valueForKey:keyPath];
    if (!array || ![array isKindOfClass:[NSMutableArray class]]) {
        array = [[NSMutableArray alloc] init];
    }
    if (![array containsObject:observer]) {
        [array addObject:observer];
    }
    [mDict setValue:array forKey:keyName];

    objc_setAssociatedObject(self, key_associated, mDict, OBJC_ASSOCIATION_RETAIN_NONATOMIC);

}

在这个方法中，第一步我们创建新类的名字，即原类名加上LKVO的后缀，然后在Runtime中搜索这个类，如果没有搜到，就新创建一个。第二步创建类的过程中替换他的getClass方法，替换如下：

	Class fakeClassMethod(id self, SEL _cmd) {

    Class super_class = class_getSuperclass(object_getClass(self));
    struct objc_super *super = (struct objc_super *)malloc(sizeof(struct objc_super));
    super->receiver = self;
    super->super_class = super_class;

    typedef void (*MsgSendType)(struct objc_super*, SEL);
    MsgSendType msgSendType = (MsgSendType)objc_msgSendSuper;
    free(super);

    msgSendType(super, _cmd);
    return super_class;

	}
在替换方法中会调用一次super的方法，但并不会返回super方法的返回值，因为super.class返回的依旧是Class Person，因此要返回通过class_getSuperclass获取的父类。值得注意的是，如果使用者重写了Person的getClass方法，比如让它返回个[NSString class]，那么调用[Person class]返回的依旧是Person，原因就在于方法被重写了，使用官方的KVO也会有这样的问题。

第三步向新类中添加或替换相应属性的setter方法，当新类中不包含该方法时，class_replaceMethod会调用class_addMethod。

第四步调用object_setClass，将self的isa指向新类。

第五步要建立一个NSDictionary，并将它与对象绑定起来，NSDictionary中要存储每个keypath对应的监听者对象的数组，当调用setter方法时，会通过NSDictionary找到keypath对应的NSArray，对NSArray中的每一个监听者调用
l_observingWithKeyPath:object:change:方法。

接下来就要重写setter的方法：

	void methodSetter(id self, SEL _cmd, NSObject *newValue) {

    // invoke setter method from superClass
    struct objc_super *super = (struct objc_super *)malloc(sizeof(struct objc_super));
    super->receiver = self;
    super->super_class = class_getSuperclass(object_getClass(self));
    typedef void (*MsgSendType)(struct objc_super*, SEL, NSObject*);
    MsgSendType msgSend = (MsgSendType)objc_msgSendSuper;
    msgSend(super, _cmd, newValue);
    free(super);

    // get key path
    NSString *methodName = NSStringFromSelector(_cmd);
    methodName = [methodName substringWithRange:NSMakeRange(3, methodName.length-4)];
    NSString *keyPath = nil;
    if (methodName.length == 1) {
        keyPath = [methodName lowercaseString];
    } else {
        keyPath = [NSString stringWithFormat:@"%@%@", [[methodName substringWithRange:NSMakeRange(0, 1)] lowercaseString], [methodName substringWithRange:NSMakeRange(1, methodName.length-1)]];
    }

    // invoke observing method
    NSDictionary *dict = objc_getAssociatedObject(self, key_associated);
    NSArray *array = [dict valueForKey:keyPath];
    if (array && [array isKindOfClass:[NSArray class]]) {
        for (NSObject *obj in array) {
            [obj l_observingWithKeyPath:keyPath object:self change:@{@"newValue":newValue}];
        }
    }

	}

首先要调用父类的setter方法，这样就完成了属性的赋值并且执行了使用者在setter中添加的其他代码。然后通过传入的SEL _cmd来获取方法名，通过方法名获取keypath的值。最后一步通过keypath在绑定的NSDictionary中找到监听改属性的对象的NSArray，依次调用他们的l_observingWithKeyPath:object:change:方法。

最后附上示例代码地址[https://github.com/zyuce/LKVO_Simulate](https://github.com/zyuce/LKVO_Simulate)
