---
title: The New Start
date: 2016-10-23 11:44:20
tags:
categories:
- WeeklyDiary
---
From this week, I will start to write weekly diary. Can not write some profound content, just talk some nonsense. On one hand, I like English, I could practice English by diary, on the other hand, it can be written as a weekly record of life, the release of emotions, so why not?~ Graduation for three months, I can feel my rapid changes in my mind, and my time also goes by more faster than the original. Maybe I will think the passage of my time is calculated by month without weekly diary. But if I have written diaries, a month will be divided into four time to me at least, perhaps I will think the time is more slower, the life is more longer. Cherish the most beautiful youth, and strive to become better.