---
title: The Trip of Fragrance Hills
date: 2016-10-30 11:20:05
tags:
categories:
- WeeklyDiary
---
Yesterday I climbed the Fragrance Hills, the famous red leaves ornamental attraction. Many People asked why go there? The tourists to the Fragrance Hills are so many, so crowded, and can not necessarily see red leaves. A lot of People said it is more in name than in reality. Like many attractions have such comment, it is just a big fame, in fact is not good. People just expect too much of them. However, I think wherever place you travel, you need to take a walk to the famous scenics of the place. Only people visited, are eligible to share their feelings. A famous scenic must have the reason of its fame. There are many reasons, the beauty just maybe one of them. Whatever, although the journey of the Fragrance Hills is crowded, although I have not seen the red autumnal leaves, but it is worth for me.